
import './App.css'
import Sobre from './components/Sobre'
import Imagem from './components/Imgem'
import Titulo from './components/Titulo'
import Galeria from './components/Galeria'

function App() {

  return (
   <div>
      <Titulo />
      <Imagem />
      <Sobre />
      <Galeria />
   </div>
  )
}

export default App

