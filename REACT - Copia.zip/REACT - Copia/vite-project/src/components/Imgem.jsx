function Imagem(){
    return(
        <section>
        <img src="./gato0.png" className="Imagem"/>
      </section>
    )
}

export default Imagem;