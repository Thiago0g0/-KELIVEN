function Titulo(){
    return(
        <header className="Titulo">
        <h1>Gatos</h1>
      </header>
    )
}

export default Titulo;