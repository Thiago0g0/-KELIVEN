function Galeria(){
    return(
        <section>
        <img src="./gato1.png" className="Galeria"/>
        <img src="./gato2.png" className="Galeria"/>
        <img src="./gato3.png" className="Galeria"/>
        <img src="./gato4.png" className="Galeria"/>
        <img src="./gato5.png" className="Galeria"/>
        <img src="./gato6.png" className="Galeria"/>
        </section>
    )
}

export default Galeria