function Sobre(){
    return(
        <section className="Sobre">
        <h2>Sobre eles:</h2>
        <p>São brincalhões, muito independentes, curiosos e conseguem ser teimosos,
           mas são também extremamente amigáveis e afetivos.</p>

           <h1>Galeria</h1>
      </section>

    )
}
export default Sobre;